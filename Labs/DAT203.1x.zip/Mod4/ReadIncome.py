def read_income(pathName = "SET-YOUR-PATH-HERE", fileName = "Adult Census Income Binary Classification dataset.csv"):
    ## Load the data  
    import pandas as pd
    import os

    ## Read the .csv file
    filePath = os.path.join(pathName, fileName)
    return pd.read_csv(filePath)
