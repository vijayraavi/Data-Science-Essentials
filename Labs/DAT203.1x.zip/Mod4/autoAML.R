## Read the data frame from the input port
auto.price <- maml.mapInputPort(1)

## Coerce some character columns to numeric
cols <- c('price', 'bore', 'stroke', 
          'horsepower', 'peak-rpm')
auto.price[, cols] <- lapply(auto.price[, cols], as.numeric)

## remove rows with NAs 
auto.price <- auto.price[complete.cases(auto.price), ]

## Create a scatter plot
require(ggplot2)
title <- paste("price vs. length with color by aspiration")
ggplot(auto.price, aes(length, price)) +
  geom_point(aes(color = factor(aspiration))) +
  ggtitle(title)
