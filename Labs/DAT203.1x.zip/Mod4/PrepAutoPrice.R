
## Define a function to join the data frames
join.auto <- function(autos, makes){
  require(dplyr) ## Make sure dplyr is loaded
  left_join(autos, makes, by = 'autonum')
}

## R code to join the two input tables
autos <- maml.mapInputPort(1) # read autos data frame from port 1
makes <- maml.mapInputPort(2) # read makes data frame from port 2
out <- join.auto(autos, makes) ## Join the data frames
maml.mapOutputPort("out") ## Output the joined data frame



## Function to clean and prepare the auto data
prep.auto <- function(df, col.names){
  require(dplyr) ## Make sure dplyr is loaded
  
  ## set the column names. 
  names(df) <- col.names
  
  ## Eliminate unneeded columns
  df <- df[,!(names(df) %in% 
                c('symboling', 'normalized.losses', 'Unnamed1', 'Unnamed2'))]
 
  ## Coerce some character columns to numeric 
  ## Uncomment if NOT in Azure ML
  # cols <- c('price', 'bore', 'stroke', 'horsepower', 'peak.rpm')
  # df[, cols] <- lapply(df[, cols], as.numeric)

  ## Add a log transformed column for price using dplyr mutate
  df <- df %>% mutate(lnprice = log(price))
  
  ## Remove rows with NAs 
  df <- df[complete.cases(df), ]
  
  ## Remove duplicate rows using unique key, autonum
  df <- df %>% filter (! duplicated(autonum))
  
  ## Consolidate the number of cylinders
  df <- df %>%
    mutate(num.cylinders = ifelse(num.of.cylinders %in% c("four", "three", "two"), "three-four",
           ifelse(num.of.cylinders %in% c("five", "six"), "five-six", "eight-twelve")))
  df
}

## Define column names
col.names <- c('Unnamed1', 'symboling', 'normalized.losses', 'fuel.type', 'aspiration', 'num.of.doors',
               'body.style', 'drive.wheels', 'engine.location', 'wheel.base',
               'length', 'width', 'height', 'curb.weight', 'engine.type',
               'num.of.cylinders', 'engine.size', 'fuel.system', 'bore', 'stroke',
               'compression.ratio', 'horsepower', 'peak.rpm', 'city.mpg',
               'highway.mpg', 'price', 'autonum', 'Unnamed2', 'make')

## R code to prep and join the auto data
autos.price <- maml.mapInputPort(1) # read autos data frame from port 1
out <- prep.auto(autos.price, col.names) ## Join the data frames
maml.mapOutputPort("out") ## Output the prepared data frame