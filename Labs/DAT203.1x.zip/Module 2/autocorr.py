def autoCorr(df, colm):
    import matplotlib.pyplot as plt
    import pandas as pd
    
    ## Create a scatter plot of the feature vs. price
    fig = plt.figure(1, figsize=(9, 9))
    ax = fig.gca()
    df.plot(kind = 'scatter', x = 'price', y = colm, ax = ax)
    
    ## Comoute the correlation and covariance and return the 
    ## values as a pandas series
    corr = df[['price', colm]].corr(method='pearson').as_matrix()[0][1]
    cov = df[['price', colm]].cov().as_matrix()[0][1]
    return pd.Series([corr, cov], index = ['Correlation', 'Covariance'])