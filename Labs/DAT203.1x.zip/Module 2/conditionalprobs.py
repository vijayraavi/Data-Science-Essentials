def auto_hist_cond(df, col, cond_col):
    import matplotlib.pyplot as plt
    import numpy as np
    
    ## Find the unique values of the conditioning variable
    conds = df[cond_col].unique()
    
    ## Set variables needed for the plots
    bwidth = (df[col].max() - df[col].min())/30
    bins = np.arange(df[col].min(), df[col].max() + bwidth, bwidth)
    num_cond = df[cond_col].unique().shape[0]
    
    ## Create one histogram in the stack for each conditionig value
    fig, ax = plt.subplots(num_cond, 1, figsize = (12,10))
    for i, val in enumerate(conds):
        temp = df.ix[df[cond_col] == val, col].as_matrix()
        if temp.shape[0] > 1:
            ax[i].hist(temp, bins = bins, alpha = 0.7)
            plt.ylabel(val)

            plt.xlabel(col)
    return(col, cond_col)

    
def auto_quantile(df, col, quantile):
    return df[col].quantile(quantile)
    
def auto_ci_cond(df, col, cond_col, quantile):
    import pandas as pd
    
    ## Compute the confidence intervales of the entire column
    ## an place in a list
    out = []
    out.append(auto_quantile(df, col, quantile))
    
    ## Append the confidence intervals of the conditional 
    ## distributions to the list
    conds = df[cond_col].unique().tolist()
    for i, val in enumerate(conds):
        temp = df.ix[df[cond_col] == val, ]
        if temp.shape[0] > 1:
            out.append(auto_quantile(temp, col, quantile))
    
    ## Create a list of index (row) names and output a data frame      
    idx = []
    idx.append('All')
    [idx.append(x) for x in conds]         
    df_out =  pd.DataFrame(out, index = idx) 
    return df_out
