cond.hist <- function(df = auto.price, col = 'price', val = 'num.cylinders'){
  require(ggplot2)
  p1 <- ggplot(df, aes_string(col)) +
    geom_histogram() +
    facet_grid(num.cylinders ~ .)
  print(p1)
}


comp.ci <- function(df = auto.price, col = 'price', quantile = 0.05){
  vec <- df[, col]
  lower <- quantile/2.0
  upper <- 1.0 - lower
  c(quantile(vec, probs = lower, na.rm = TRUE),
    quantile(vec, probs = upper, na.rm = TRUE))
}


condition.ci <- function(df = auto.price, col = 'price', cond.col = 'num.cylinders', quantile = 0.05){
  ## Compute the quantiles for unconditioned distribution
  all <- comp.ci(df = df, col = col, quantile = quantile)
  
  ## Computed the conditioned quantiles and bind them into a dataframe
  val.list <- as.list(unique(df[, cond.col]))
  ci  <- lapply(val.list, function(x) comp.ci(df[df[, cond.col] == x, ], col = col, quantile = quantile))
  ci <- do.call(rbind.data.frame, ci)
  
  ## Bind the quantiles for unconditioned into the conditioned data frame
  ## and assign meaningful row and column names
  out <- rbind(all, ci)
  names(out) <- c(as.character(quantile/2), as.character(1 - quantile/2))
  rownames(out) <- c('All', val.list)
  out
}
