auto.corr <- function(df = auto.price, colm = 'engine.size'){
  
  ## Plot the column selected vs. price
  require(ggplot2)
  print(ggplot(df, aes_string('price', colm)) +
    geom_point())
  
  ## Compute the covariance and correlation
  covar <- cov(df[, c('price', colm)])[1,2]
  corr <- cor(df[, c('price', colm)])[1,2]
  
  ## Format and print the covariance and correlation
  covar <- as.character(round(covar, 1))
  corr <- as.character(round(corr, 2))
  print(paste('For auto price and ', colm, ':', sep = ''))
  print( paste('Covariance = ', covar))
  print( paste('Correlaiton = ', corr))
}