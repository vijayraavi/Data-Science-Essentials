read.auto <- function(path = 'c:/dat203.1x/mod2'){
  ## Read the csv file
  filePath <- file.path(path, 'Automobile price data _Raw_.csv')
  auto.price <- read.csv(filePath, header = TRUE, 
                         stringsAsFactors = FALSE)
  
  ## Coerce some character columns to numeric
  cols <- c('price', 'bore', 'stroke', 
            'horsepower', 'peak.rpm')
  auto.price[, cols] <- lapply(auto.price[, cols], as.numeric)
  
  ## remove rows with NAs 
  auto.price <- auto.price[complete.cases(auto.price), ]
  
  ## Add a log transformed column for price
  auto.price$lnprice <- log(auto.price$price)
  
  ## Consolidate the number of cylinders
  auto.price$num.cylinders <- 
    ifelse(auto.price$num.of.cylinders %in% c("four", "three"), "three-four",
           ifelse(auto.price$num.of.cylinders %in% c("five", "six"), "five-six", "eight-twelve"))
  
  auto.price
}

auto.describe <- function(df, col){
  tmp <- df[, col]
  sumry <- summary(tmp)
  nms <- names(sumry)
  nms <- c(nms, 'std')
  out <- c(sumry, sd(tmp))
  names(out) <- nms
  out
}

plot.auto <- function(df = auto.price, val = 'price', num.bin = 30){
  require(ggplot2)
  require(gridExtra)
  dat <- as.factor('')
  
  ## Compute bin width
  bin.width <- (max(df[, val]) - min(df[, val]))/num.bin
  
  ## Plot a histogram
  p1 <- ggplot(df, aes_string(val)) +
    geom_histogram(binwidth = bin.width)
  
  ## A simple boxplot
  p2 <- ggplot(df, aes_string(dat, val)) +
    geom_boxplot() + coord_flip() + ylab('')
  
  ## Now stack the plots
  grid.arrange(p2, p1, nrow = 2)
}