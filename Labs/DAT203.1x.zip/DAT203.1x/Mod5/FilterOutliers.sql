SELECT *
FROM t1
WHERE enginesize < 190
AND weight < 3500
AND citympg < 40;