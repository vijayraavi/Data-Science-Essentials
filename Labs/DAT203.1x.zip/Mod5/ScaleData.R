num.cols <- c("wheel.base",
               "length",
               "width",
               "height",
               "curb.weight",
               "engine.size",
               "bore",
               "stroke",
               "compression.ratio",
               "horsepower",
               "peak.rpm",
               "city.mpg",
               "highway.mpg",
               "lnprice")
               
auto.price <- maml.mapInputPort(1) # read autos data frame from port 1
auto.price[, num.cols] <- scale(auto.price[, num.cols]) # scale numeric columns
maml.mapOutputPort("auto.price") ## Output the data frame
