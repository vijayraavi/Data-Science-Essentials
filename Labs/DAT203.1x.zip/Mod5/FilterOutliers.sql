SELECT *
FROM t1
WHERE [engine-size] < 190
AND [curb-weight] < 3500
AND [city-mpg] < 40