## Function to clean and prepare the auto data
prep.auto <- function(df, col.names){
  require(dplyr) ## Make sure dplyr is loaded
  
  ## set the column names. 
  names(df) <- col.names
  
  ## Eliminate unneeded columns
  df <- df[,!(names(df) %in% 
                c('symboling', 'normalized.losses', 'make.id'))]
 
  ## Coerce some character columns to numeric 
  ## Uncomment if NOT in Azure ML
  # cols <- c('price', 'bore', 'stroke', 'horsepower', 'peak.rpm')
  # df[, cols] <- lapply(df[, cols], as.numeric)

  ## Add a log transformed column for price using dplyr mutate
  df <- df %>% mutate(lnprice = log(price))
  
  ## Remove rows with NAs 
  df <- df[complete.cases(df), ]
  
  ## Remove duplicate rows
  df <- df %>% filter (! duplicated(df,))
  
  ## Consolidate the number of cylinders
  df <- df %>%
    mutate(num.of.cylinders = ifelse(num.of.cylinders %in% c("four", "three", "two"), "three-four",
           ifelse(num.of.cylinders %in% c("five", "six"), "five-six", "eight-twelve")))
  df
}

## Define column names (change - to . for R)
col.names <- c('symboling', 'normalized.losses', 'make.id', 'fuel.type', 'aspiration', 'num.of.doors',
               'body.style', 'drive.wheels', 'engine.location', 'wheel.base',
               'length', 'width', 'height', 'curb.weight', 'engine.type',
               'num.of.cylinders', 'engine.size', 'fuel.system', 'bore', 'stroke',
               'compression.ratio', 'horsepower', 'peak.rpm', 'city.mpg',
               'highway.mpg', 'price', 'make')

## R code to prep the auto data
autos.price <- maml.mapInputPort(1) # read autos data frame from port 1
out <- prep.auto(autos.price, col.names) # Transform the data
maml.mapOutputPort("out") ## Output the prepared data frame