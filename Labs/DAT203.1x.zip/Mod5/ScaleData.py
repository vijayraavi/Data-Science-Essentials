def azureml_main(df):   
    from sklearn import preprocessing as pr

   ## Define numeric column names
    num_cols = ['wheel-base', 'length', 'width', 'height',
                'curb-weight', 'engine-size', 'bore', 'stroke',
                 'compression-ratio', 'horsepower', 'peak-rpm', 
		      'city-mpg', 'highway-mpg', 'lnprice']
 
    ## Scale the numeric cols
    arry = df[num_cols].as_matrix() # Create numpy array
    ## Scale numpy array by columns and assign to 
    ## columns of the Pandas data frame.
    df[num_cols] = pr.scale(arry, axis = 0)
    return df
