select 
  CheckingAcctStat,
  Duration,
  CreditHistory,
  Purpose,
  Savings,
  Employment,
  InstallmentRatePecnt,
  PresentResidenceTime,
  Property,
  Age,
  Telephone,
  CreditStatus
  from t1;