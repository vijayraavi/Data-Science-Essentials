read.income <- function(path = 'SET-PATH-HERE'){
  ## Read the csv file
  filePath <- file.path(path, 'Adult Census Income Binary Classification dataset.csv')
  read.csv(filePath, header = TRUE, stringsAsFactors = FALSE)
}