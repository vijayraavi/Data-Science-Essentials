def azureml_main(auto_price):   
    ## Create subsets fo the data
    temp1 = auto_price.ix[auto_price['aspiration'] == 'std']       
    temp2 = auto_price.ix[auto_price['aspiration'] == 'turbo']          
    
    ## Create scatter plot for each subset
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(6, 6))
    ax = fig.gca()
    if temp1.shape[0] > 0:                    
        temp1.plot(kind = 'scatter', x = 'length', y = 'price' , 
                           ax = ax, color = 'DarkBlue')                          
    if temp2.shape[0] > 0:                    
        temp2.plot(kind = 'scatter', x = 'length', y = 'price' , 
                           ax = ax, color = 'Red') 
    ax.set_title('Scatter plot of price vs. length with color by aspiratione')
    fig.savefig('auto-plot.png')
    return auto_price

